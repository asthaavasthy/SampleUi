using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SampleUI.Models;
using System.Collections.Generic;
using System.Diagnostics;

namespace SampleUI.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var model = new AIGenerative
            {
                Languages = new List<SelectListItem>()
                {
                    new SelectListItem { Text = "English", Value = "1" },
                    new SelectListItem { Text = "Telugu", Value = "2" },
                    new SelectListItem { Text = "Hindi", Value = "3" }

                }
            };
            return View(model);
        }

        [HttpPost]
        public ActionResult Add(AIGenerative objInfo)
        {
            // now AIGenerative has the value that user entered on form
            return View(objInfo);
        }
    }
}
